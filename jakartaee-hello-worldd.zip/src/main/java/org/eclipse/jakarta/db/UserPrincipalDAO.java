package org.eclipse.jakarta.db;

import java.nio.file.attribute.UserPrincipal;

import javax.ejb.Stateful;
import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

@Stateful
public class UserPrincipalDAO {

    @PersistenceContext(unitName = "hello_PU", type = PersistenceContextType.EXTENDED)
    EntityManager em;

    public void create(UserPrincipal userPrincipal) {
        em.persist(userPrincipal);
    }
}
